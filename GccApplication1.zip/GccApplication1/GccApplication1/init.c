#include "init.h"

volatile int i;
int a[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x08,0x03,0x46,0x21,0x06,0x0E};

void timer_init()
{
	
	TCCR1B |= (1<<WGM12)| (1<<CS12) | (1<<CS10); //CTC
	TCNT1=0;
	OCR1A = 14404;
	TIMSK |= (1<<4);
	sei();
	
}


void value(void){
	PORTB=a[i];
}

int citire(){
	
	DDRD = (1<<0);
	PORTD =(1<<0);
	//_delay_ms(10);
	if(PIND & (1<<4) != 0){
		return 0;
	}
	if(PIND & (1<<5) != 0){
		return 1;
	}
	if(PIND & (1<<6) != 0){
		return 2;
	}
	if(PIND & (1<<7) != 0){
		return 3;
	}
	
	
	DDRD = (1<<1);
	PORTD =(1<<1);
	if(PIND & (1<<4) != 0){
		return 4;
	}
	if(PIND & (1<<5) != 0){
		return 5;
	}
	if(PIND & (1<<6) != 0){
		return 6;
	}
	if(PIND & (1<<7) != 0){
		return 7;
	}
	
	
	DDRD = (1<<2);
	PORTD =(1<<2);
	if(PIND & (1<<4) != 0){
		return 8;
	}
	if(PIND & (1<<5) != 0){
		return 9;
	}
	if(PIND & (1<<6) != 0){
		return 10;
	}
	if(PIND & (1<<7) != 0){
		return 11;
	}


	DDRD = (1<<3);
	PORTD =(1<<3);
	if(PIND & (1<<4) != 0){
		return 12;
	}
	if(PIND & (1<<5) != 0){
		return 13;
	}
	if(PIND & (1<<6) != 0){
		return 14;
	}
	if(PIND & (1<<7) != 0){
		return 15;
	}
	
	return -1;
}