/*
 * GccApplication1.c
 *
 * Created: 3/20/2017 6:31:31 PM
 * Author : dspuser
 */ 


#include "init.h"

volatile int i;
/*
ISR(TIMER1_COMPA_vect)
{ 
	
	value();
	i++;
	if(i==16)
	i=0;
}
*/

extern int a[];

int main(void)
{
    /* Replace with your application code */
	
	DDRB=0xFF;
	DDRD=0xF0;
	
    //timer_init();
	
	int tasta;
	
	while(1){
		
		tasta=citire();
		
		if(tasta != -1)
		{
			PORTB=a[tasta];
		}
		
	}
		
   
}

