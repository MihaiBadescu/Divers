#include "init.h"

volatile int i;
int a[]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90};

void timer_init()
{
	
	TCCR1B |= (1<<WGM12)| (1<<CS12) | (1<<CS10); //CTC
	TCNT1=0;
	OCR1A = 14404;
	TIMSK |= (1<<4);
	sei();
	
}



void value(void){
	PORTB=a[i];
}
