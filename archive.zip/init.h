#define F_CPU 14745600UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#ifndef init.h

#define init.h

void timer_init();



#endif