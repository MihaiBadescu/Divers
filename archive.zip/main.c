/*
 * GccApplication1.c
 *
 * Created: 3/20/2017 6:31:31 PM
 * Author : dspuser
 */ 


#include "init.h"
volatile int i;

ISR(TIMER1_COMPA_vect)
{ 
	
	value();
	i++;
	if(i==10)
	i=0;
}


int main(void)
{
    /* Replace with your application code */
	
	DDRB=0xFF;
	
    timer_init();
	

	while(1);
		
   
}

