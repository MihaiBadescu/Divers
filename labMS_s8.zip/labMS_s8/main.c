/*
 * GccApplication1.c
 *
 * Created: 3/20/2017 6:31:31 PM
 * Author : dspuser
 */ 


#include "init.h"

volatile int i;
/*
ISR(TIMER1_COMPA_vect)
{ 
	
	value();
	i++;
	if(i==16)
	i=0;
}
*/

 int a[100]={0xC0,0xF9,0xA4,0xB0,0x99,0x92,0x82,0xF8,0x80,0x90,0x08,0x03,0x46,0x21,0x06,0x0E};
 int tasta = -1;

int main(void)
{
    /* Replace with your application code */
	
	DDRB=0xFF;
	DDRD=0xFF;
	
    //timer_init();
	
	
	
	while(1){
		
		tasta=citire();
				
		if(tasta != -1)
		{
			//_delay_ms(10);
			PORTB=a[tasta];
			//_delay_ms(10);
		}
		
	}
		
   
}

