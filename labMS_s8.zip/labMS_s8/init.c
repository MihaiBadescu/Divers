#include "init.h"

volatile int i;


void timer_init()
{
	
	TCCR1B |= (1<<WGM12)| (1<<CS12) | (1<<CS10); //CTC
	TCNT1=0;
	OCR1A = 14404;
	TIMSK |= (1<<4);
	sei();
	
}
/*
int scanare(void)
{
    volatile int rand,coloana;
 
    for(rand=0;rand<4;rand++)
    {
        DDRD  = 1<<rand;
        PORTD = ~(1<<rand);
        _delay_us(10);
 
        for(coloana=4;coloana<8;coloana++)
        {
            if( (PIND & (1<<coloana)) == 0)
            {
                return rand + (coloana - 4)*4;
            }
        }
    }
return -1;
}
*/

int citire(){
	
	//coloana 1
	//_delay_ms(10);
	DDRD = (1<<0);
	PORTD =~(1<<0);
	
	
	if((PIND & (1<<4)) == 0){
		return 0;
	}
	if((PIND & (1<<5)) == 0){
		return 4;
	}
	if((PIND & (1<<6)) == 0){
		return 8;
	}
	if((PIND & (1<<7)) == 0){
		return 12;
	}
	

	//coloana 2
	//_delay_ms(10);
	DDRD = (1<<1);
	PORTD =~(1<<1);
	if((PIND & (1<<4)) == 0){
		return 1;
	}
	if((PIND & (1<<5)) == 0){
		return 5;
	}
	if((PIND & (1<<6)) == 0){
		return 9;
	}
	if((PIND & (1<<7)) == 0){
		return 13;
	}
	

	//coloana 3
	//_delay_ms(10);
	DDRD = (1<<2);
	PORTD =~(1<<2);
	if((PIND & (1<<4)) == 0){
		return 2;
	}
	if((PIND & (1<<5)) == 0){
		return 6;
	}
	if((PIND & (1<<6)) == 0){
		return 10;
	}
	if((PIND & (1<<7)) == 0){
		return 14;
	}


	//coloana 4
	//_delay_ms(10);
	DDRD = (1<<3);
	PORTD =~(1<<3);
	if((PIND & (1<<4)) == 0){
		return 3;
	}
	if((PIND & (1<<5)) == 0){
		return 7;
	}
	if((PIND & (1<<6)) == 0){
		return 11;
	}
	if((PIND & (1<<7)) == 0){
		return 15;
	}
	
	return -1;
}